import { useEffect, useState } from 'react'
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, CartesianGrid } from 'recharts'
import { Activity, BrainCircuit, Map as MapIcon, Factory, Gauge, AlertTriangle, Lightbulb, RefreshCw } from 'lucide-react'

const API = 'http://127.0.0.1:8000'
const defaultProduction = {
  downtime_hours: 4, rainfall_mm: 35, blasting_delay_hours: 2,
  available_trucks: 7, worker_availability: 0.88, planned_tonnes: 1000
}
function Metric({ icon: Icon, label, value, sub }) {
  return <div className="metric"><div className="metric-top"><span>{label}</span><Icon size={19}/></div><div className="metric-value">{value}</div><div className="muted">{sub}</div></div>
}
export default function App() {
  const [dashboard, setDashboard] = useState(null)
  const [zones, setZones] = useState([])
  const [form, setForm] = useState(defaultProduction)
  const [forecast, setForecast] = useState(null)
  const [mineral, setMineral] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function loadData() {
    setError('')
    try {
      const [d, z] = await Promise.all([
        fetch(`${API}/api/dashboard`).then(r => { if (!r.ok) throw new Error('Backend error'); return r.json() }),
        fetch(`${API}/api/zones`).then(r => r.json())
      ])
      setDashboard(d); setZones(z.zones)
    } catch {
      setError('Cannot connect to backend. Start FastAPI in the backend folder (port 8000), then refresh.')
    }
  }
  useEffect(() => { loadData() }, [])

  async function runForecast(e) {
    e.preventDefault(); setLoading(true); setError('')
    try {
      const res = await fetch(`${API}/api/production/predict`, {
        method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(form)
      })
      if (!res.ok) throw new Error('Prediction request failed')
      setForecast(await res.json())
    } catch { setError('Prediction failed. Check that the backend is running.') }
    finally { setLoading(false) }
  }
  async function runMineralDemo() {
    setLoading(true); setError('')
    try {
      const res = await fetch(`${API}/api/mineral/predict`, {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ndvi:0.34,ndmi:0.18,swir_proxy:0.61,geology_score:0.82,distance_km:2.5,slope_deg:11,soil_moisture:0.29})
      })
      setMineral(await res.json())
    } catch { setError('Mineral model request failed. Check the backend.') }
    finally { setLoading(false) }
  }
  function update(key, value) { setForm(old => ({...old, [key]: Number(value)})) }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-icon"><Activity/></div><div><b>MANGAN AI</b><small>MINING INTELLIGENCE</small></div></div>
      <div className="nav-label">WORKSPACE</div>
      <a className="nav active"><Gauge size={18}/> Overview</a>
      <a className="nav" href="#explorer"><MapIcon size={18}/> Mineral explorer</a>
      <a className="nav" href="#forecast"><BrainCircuit size={18}/> AI predictions</a>
      <a className="nav" href="#operations"><Factory size={18}/> Operations</a>
      <div className="sidebar-bottom"><span className="live-dot"/> Prototype environment<small>SIH26009 · MOIL</small></div>
    </aside>

    <main className="main">
      <header className="topbar"><div><div className="eyebrow">SMART MINING / DECISION SUPPORT</div><h1>Mining intelligence dashboard</h1><p className="muted">Explore potential zones. Forecast production. Understand operational risk.</p></div><button className="secondary" onClick={loadData}><RefreshCw size={16}/> Refresh</button></header>
      <div className="demo-banner"><AlertTriangle size={17}/><span><b>DEMO DATA:</b> All metrics, model outputs and map points are illustrative synthetic data, not MOIL operational records.</span></div>
      {error && <div className="error">{error}</div>}
      <section className="metrics-grid">
        <Metric icon={Factory} label="Today's production" value={dashboard ? `${dashboard.production_today.toLocaleString()} t` : '—'} sub="Illustrative actual output"/>
        <Metric icon={Gauge} label="Production target" value={dashboard ? `${dashboard.production_target.toLocaleString()} t` : '—'} sub="Illustrative daily target"/>
        <Metric icon={MapIcon} label="Exploration zones" value={dashboard?.prospectivity_zones ?? '—'} sub="Demo priority areas"/>
        <Metric icon={Activity} label="Equipment availability" value={dashboard ? `${dashboard.equipment_availability}%` : '—'} sub="Illustrative availability"/>
      </section>

      <section className="content-grid">
        <div className="panel chart-panel">
          <div className="panel-heading"><div><h2>Production performance</h2><p className="muted">Last seven demo days · tonnes</p></div><span className="pill">7 DAYS</span></div>
          {dashboard && <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={dashboard.production_history}><defs><linearGradient id="actualFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#39c6a0" stopOpacity={0.3}/><stop offset="95%" stopColor="#39c6a0" stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" stroke="#243244"/><XAxis dataKey="day" stroke="#8493a7"/><YAxis stroke="#8493a7"/><Tooltip contentStyle={{background:'#101d2c',border:'1px solid #2a3b50',borderRadius:10}}/><Area type="monotone" dataKey="target" stroke="#8092aa" strokeDasharray="5 5" fill="none"/><Area type="monotone" dataKey="actual" stroke="#39c6a0" fill="url(#actualFill)" strokeWidth={2}/></AreaChart>
          </ResponsiveContainer>}
          <div className="legend"><span><i className="green"/> Actual production</span><span><i className="grey"/> Target</span></div>
        </div>
        <div className="panel status-panel" id="operations">
          <div className="panel-heading"><div><h2>Operational status</h2><p className="muted">Illustrative indicators</p></div></div>
          <div className="risk-row"><span>Shortfall risk</span><b className="risk-medium">{dashboard?.shortfall_risk ?? '—'}</b></div>
          <div className="risk-row"><span>Equipment availability</span><b>{dashboard ? `${dashboard.equipment_availability}%` : '—'}</b></div>
          <div className="risk-row"><span>Production achievement</span><b>{dashboard ? `${Math.round(dashboard.production_today/dashboard.production_target*100)}%` : '—'}</b></div>
          <div className="note"><Lightbulb size={17}/><span>Use the forecast tool below to test how downtime, rainfall and delays affect estimated output.</span></div>
        </div>
      </section>

      <section className="panel map-panel" id="explorer">
        <div className="panel-heading"><div><h2>Mineral prospectivity explorer</h2><p className="muted">Illustrative map points · not verified mineral locations</p></div><span className="pill">GIS DEMO</span></div>
        <div className="map-wrap"><MapContainer center={[21.82,80.23]} zoom={11} scrollWheelZoom={true} style={{height:'100%',width:'100%'}}><TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/>{zones.map(z => <CircleMarker key={z.id} center={[z.lat,z.lng]} radius={10} pathOptions={{color:z.priority==='High'?'#fb7185':z.priority==='Medium'?'#fbbf24':'#39c6a0',fillOpacity:.55}}><Popup><b>{z.name}</b><br/>Demo score: {(z.score*100).toFixed(0)}%<br/>Priority: {z.priority}</Popup></CircleMarker>)}</MapContainer></div>
        <div className="zone-list">{zones.map(z=><div className="zone" key={z.id}><span className={`zone-dot ${z.priority.toLowerCase()}`}/><span>{z.name}</span><b>{z.priority}</b></div>)}</div>
        <button onClick={runMineralDemo} className="primary"><BrainCircuit size={16}/> Run mineral model demo</button>
        {mineral && <div className="result-box"><b>Demo model output: {mineral.priority} prospectivity</b><div className="score">{mineral.prospectivity_score}% <small>model score</small></div><p>{mineral.notice}</p><div className="feature-list">{mineral.top_model_features.map(f=><span key={f.feature}>{f.feature.replaceAll('_',' ')}: {f.importance}</span>)}</div></div>}
      </section>

      <section className="panel forecast-panel" id="forecast">
        <div className="panel-heading"><div><h2>Production shortfall predictor</h2><p className="muted">Adjust operating conditions and run the model</p></div><span className="pill">RANDOM FOREST</span></div>
        <form onSubmit={runForecast} className="form-grid">
          <label>Equipment downtime (hours)<input type="number" min="0" max="24" step="0.5" value={form.downtime_hours} onChange={e=>update('downtime_hours',e.target.value)}/></label>
          <label>Rainfall (mm)<input type="number" min="0" max="500" step="1" value={form.rainfall_mm} onChange={e=>update('rainfall_mm',e.target.value)}/></label>
          <label>Blasting delay (hours)<input type="number" min="0" max="24" step="0.5" value={form.blasting_delay_hours} onChange={e=>update('blasting_delay_hours',e.target.value)}/></label>
          <label>Available trucks<input type="number" min="0" max="100" step="1" value={form.available_trucks} onChange={e=>update('available_trucks',e.target.value)}/></label>
          <label>Worker availability (0–1)<input type="number" min="0" max="1" step="0.01" value={form.worker_availability} onChange={e=>update('worker_availability',e.target.value)}/></label>
          <label>Planned production (tonnes)<input type="number" min="1" max="100000" value={form.planned_tonnes} onChange={e=>update('planned_tonnes',e.target.value)}/></label>
          <button className="primary submit" disabled={loading}>{loading?'Running model…':'Predict production'}</button>
        </form>
        {forecast && <div className="forecast-result">
          <div className="result-stat"><small>Predicted output</small><strong>{forecast.predicted_tonnes.toLocaleString()} t</strong></div>
          <div className="result-stat"><small>Expected deficit</small><strong>{forecast.expected_deficit_tonnes.toLocaleString()} t</strong></div>
          <div className="result-stat"><small>Shortfall</small><strong>{forecast.shortfall_percent}%</strong></div>
          <div className="result-stat"><small>Risk category</small><strong className={forecast.risk==='High'?'risk-high':forecast.risk==='Medium'?'risk-medium':'risk-low'}>{forecast.risk}</strong></div>
          <div className="recommendations"><h3><Lightbulb size={17}/> Recommended review actions</h3><ul>{forecast.recommendations.map((r,i)=><li key={i}>{r}</li>)}</ul><p className="muted">{forecast.notice}</p></div>
        </div>}
      </section>
      <footer> MANGAN AI · SIH26009 · Prototype for decision support only · Not a certified reserve estimate</footer>
    </main>
  </div>
}
