from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from datetime import date, timedelta

app = FastAPI(title="MANGAN AI API", version="1.0.0",
              description="SIH26009 demonstration decision-support API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

# Deterministic synthetic training data. Replace with authorized, validated records.
rng = np.random.default_rng(26009)

# Mineral prospectivity demo features: NDVI, NDMI, SWIR proxy, geology evidence,
# distance to known occurrence (km), slope (degrees), soil moisture proxy.
n = 1200
mineral_X = pd.DataFrame({
    "ndvi": rng.uniform(-0.1, 0.85, n),
    "ndmi": rng.uniform(-0.4, 0.6, n),
    "swir_proxy": rng.uniform(0.05, 0.8, n),
    "geology_score": rng.uniform(0, 1, n),
    "distance_km": rng.uniform(0.1, 25, n),
    "slope_deg": rng.uniform(0, 40, n),
    "soil_moisture": rng.uniform(0.05, 0.65, n),
})
mineral_signal = (
    1.4 * mineral_X.geology_score
    + 0.8 * mineral_X.swir_proxy
    + 0.5 * mineral_X.ndmi
    - 0.055 * mineral_X.distance_km
    - 0.025 * abs(mineral_X.slope_deg - 12)
    + rng.normal(0, 0.45, n)
)
mineral_y = (mineral_signal > mineral_signal.quantile(0.62)).astype(int)
mineral_model = RandomForestClassifier(
    n_estimators=180, max_depth=9, min_samples_leaf=4,
    random_state=26009, class_weight="balanced"
)
mineral_model.fit(mineral_X, mineral_y)

# Production demo data. Target depends on downtime, rainfall and blasting delays.
m = 900
production_X = pd.DataFrame({
    "downtime_hours": rng.uniform(0, 12, m),
    "rainfall_mm": rng.uniform(0, 80, m),
    "blasting_delay_hours": rng.uniform(0, 8, m),
    "available_trucks": rng.integers(3, 16, m),
    "worker_availability": rng.uniform(0.65, 1.0, m),
    "planned_tonnes": rng.uniform(650, 1300, m),
})
production_y = (
    production_X.planned_tonnes
    - 22 * production_X.downtime_hours
    - 2.1 * production_X.rainfall_mm
    - 17 * production_X.blasting_delay_hours
    + 18 * production_X.available_trucks
    + 170 * production_X.worker_availability
    + rng.normal(0, 35, m)
).clip(250, 1500)
X_train, X_test, y_train, y_test = train_test_split(
    production_X, production_y, test_size=0.2, random_state=42
)
production_model = RandomForestRegressor(
    n_estimators=180, max_depth=12, min_samples_leaf=3, random_state=42
)
production_model.fit(X_train, y_train)
production_mae = float(mean_absolute_error(y_test, production_model.predict(X_test)))

class MineralInput(BaseModel):
    ndvi: float = Field(ge=-1, le=1)
    ndmi: float = Field(ge=-1, le=1)
    swir_proxy: float = Field(ge=0, le=1)
    geology_score: float = Field(ge=0, le=1)
    distance_km: float = Field(ge=0, le=100)
    slope_deg: float = Field(ge=0, le=90)
    soil_moisture: float = Field(ge=0, le=1)

class ProductionInput(BaseModel):
    downtime_hours: float = Field(ge=0, le=24)
    rainfall_mm: float = Field(ge=0, le=500)
    blasting_delay_hours: float = Field(ge=0, le=24)
    available_trucks: int = Field(ge=0, le=100)
    worker_availability: float = Field(ge=0, le=1)
    planned_tonnes: float = Field(gt=0, le=100000)

def make_recommendations(data: dict, shortfall_pct: float):
    recs = []
    if data["downtime_hours"] >= 3:
        recs.append("Review maintenance logs and equipment availability; prioritize safe, scheduled maintenance.")
    if data["rainfall_mm"] >= 25:
        recs.append("Review weather and site-access conditions before updating the shift plan.")
    if data["blasting_delay_hours"] >= 2:
        recs.append("Coordinate the approved blasting schedule with the mine planning team.")
    if data["available_trucks"] < 6:
        recs.append("Review fleet allocation and dispatch availability.")
    if shortfall_pct >= 10:
        recs.append("Reforecast the shift target using verified capacity and operational constraints.")
    if not recs:
        recs.append("No major demo risk trigger detected. Continue routine monitoring and verify live operating data.")
    return recs

@app.get("/")
def home():
    return {"name": "MANGAN AI API", "status": "running", "problem_statement": "SIH26009"}

@app.get("/api/dashboard")
def dashboard():
    history = []
    start = date.today() - timedelta(days=6)
    for i, (target, actual) in enumerate([
        (950, 910), (980, 935), (1000, 860), (970, 945),
        (1020, 890), (1000, 780), (980, 925)
    ]):
        history.append({
            "day": (start + timedelta(days=i)).strftime("%a"),
            "target": target, "actual": actual
        })
    return {
        "mine_name": "Demo Mining Site",
        "data_mode": "SYNTHETIC DEMO DATA",
        "production_today": 925,
        "production_target": 1000,
        "prospectivity_zones": 12,
        "high_priority_zones": 3,
        "equipment_availability": 87,
        "shortfall_risk": "Medium",
        "production_history": history,
        "model_mae_tonnes": round(production_mae, 1)
    }

@app.get("/api/zones")
def zones():
    # Illustrative coordinates only; not real MOIL survey points.
    return {"data_mode": "ILLUSTRATIVE DEMO LOCATIONS", "zones": [
        {"id": "Z-01", "name": "Demo Zone Alpha", "lat": 21.80, "lng": 80.20, "score": 0.88, "priority": "High"},
        {"id": "Z-02", "name": "Demo Zone Bravo", "lat": 21.84, "lng": 80.25, "score": 0.67, "priority": "Medium"},
        {"id": "Z-03", "name": "Demo Zone Charlie", "lat": 21.77, "lng": 80.29, "score": 0.39, "priority": "Low"},
        {"id": "Z-04", "name": "Demo Zone Delta", "lat": 21.86, "lng": 80.17, "score": 0.76, "priority": "Medium"},
    ]}

@app.post("/api/mineral/predict")
def predict_mineral(data: MineralInput):
    row = pd.DataFrame([data.model_dump()])
    score = float(mineral_model.predict_proba(row)[0][1])
    label = "High" if score >= 0.70 else "Medium" if score >= 0.45 else "Low"
    importance = sorted(
        zip(mineral_X.columns, mineral_model.feature_importances_),
        key=lambda x: x[1], reverse=True
    )
    return {
        "prospectivity_score": round(score * 100, 1),
        "priority": label,
        "top_model_features": [
            {"feature": name, "importance": round(float(value), 3)}
            for name, value in importance[:4]
        ],
        "notice": "Synthetic-model demonstration score, not a confirmed mineral probability or reserve estimate."
    }

@app.post("/api/production/predict")
def predict_production(data: ProductionInput):
    row = pd.DataFrame([data.model_dump()])
    predicted = max(0.0, float(production_model.predict(row)[0]))
    target = data.planned_tonnes
    deficit = max(0.0, target - predicted)
    shortfall_pct = deficit / target * 100
    risk = "High" if shortfall_pct >= 15 else "Medium" if shortfall_pct >= 7 else "Low"
    return {
        "predicted_tonnes": round(predicted, 1),
        "planned_tonnes": round(target, 1),
        "expected_deficit_tonnes": round(deficit, 1),
        "shortfall_percent": round(shortfall_pct, 1),
        "risk": risk,
        "recommendations": make_recommendations(data.model_dump(), shortfall_pct),
        "model_mae_tonnes": round(production_mae, 1),
        "notice": "Forecast uses synthetic demonstration training data. Validate against real mine records before operational use."
    }
