# MANGAN AI — SIH26009 starter prototype

Beginner-friendly React + FastAPI + scikit-learn prototype.

## Requirements
- Python 3.10+
- Node.js 20+ (LTS)
- Internet connection for installing packages and loading the OpenStreetMap basemap

## 1. Start the backend
Open a terminal in `backend/`:

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate

pip install -r requirements.txt
uvicorn main:app --reload
```

Backend: http://127.0.0.1:8000  
API documentation: http://127.0.0.1:8000/docs

## 2. Start the frontend
Open a second terminal in `frontend/`:

```bash
npm install
npm run dev
```

Open the URL printed by Vite, normally http://localhost:5173.

## 3. What works
- Dashboard KPIs and production history
- Interactive illustrative exploration map
- Mineral prospectivity model (Random Forest classifier)
- Production forecast model (Random Forest regressor)
- Shortfall risk and rule-based recommendations
- Editable production prediction inputs

## Important data and science note
The included dataset is synthetic demonstration data. Scores are not calibrated probabilities and map markers are illustrative demo locations, not confirmed mineral occurrences or reserves. Satellite imagery alone cannot establish subsurface manganese. Replace demo records with verified geological, drilling, equipment and production data before any operational use.

## Suggested team workflow
1. Member 1: frontend and UI
2. Member 2: backend/API
3. Member 3: mineral model and validated geological features
4. Member 4: production model and evaluation
5. Member 5: GIS/satellite pipeline and map layers
6. Member 6: integration, tests, documentation and demo

## Next real-data integration
- Sentinel-2: Copernicus Data Space / Google Earth Engine
- Geological and mineral occurrence data: Geological Survey of India / authorized MOIL data
- Production and equipment: authorized historical MOIL records
- Keep source, date, spatial resolution, units and quality flags for every feature.
